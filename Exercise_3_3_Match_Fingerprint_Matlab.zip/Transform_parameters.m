% FINGERPRINT ALIGNING
%
% Argument:   M1 -  First Minutiae 
%             M2 -  Second Minutiae
%             display_flag
%               
% Returns:    S - Similarity Measure
%             M1 -  First Minutiae aligned
%             M2 -  Second Minutiae aligned
%

function [bi,bj,ba] = Transform_parameters( M1, M2)
    count1=size(M1,1); count2=size(M2,1); 
    bi=0; bj=0; ba=0;   % Best i,j,alpha
    S=0;                % Best Similarity Score
    for i=1:count1
        T1=transform(M1,i);
        for j=1:count2
            if M1(i,3)==M2(j,3) % the same type: Bifurcation or Terminal
                T2=transform(M2,j);
                for a=-5:5                      %Alpha
                    T3=transform2(T2,a*pi/360);
                    negT1=find(T1(:,3)<0);
                    T1(negT1,3)=T1(negT1,3)+2*pi;
                    posT1=find(T1(:,3)>2*pi);
                    T1(posT1,3)=T1(posT1,3)-2*pi;
                    negT3=find(T3(:,3)<0);
                    T3(negT3,3)=T3(negT3,3)+2*pi;
                    posT3=find(T3(:,3)>2*pi);
                    T3(posT3,3)=T3(posT3,3)-2*pi;
                    
                    sm=score(T1,T3);
                    if S<sm
                        S=sm;
                        bi=i; bj=j; ba=a;
                    end                
                end
            end
        end
    end
end