% FINGERPRINT MATCHING SCORE
% Argument:   ff1 -  First transformed Fingerprint 
%             ff2 -  Second transformed Fingerprint
% Returns:    Distance


function Distance = Match_fingerprints(ff1,ff2)
%%TO DO

%% END TO DO
end
